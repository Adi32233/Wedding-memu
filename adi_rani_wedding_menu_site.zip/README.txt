עדי ורני - אתר תפריט חתונה

מה יש בתיקייה:
- index.html  -> האתר
- menu.pdf    -> התפריט

העלאה ל-GitHub Pages:
1. פתחו repository חדש ב-GitHub.
2. העלו את שני הקבצים index.html ו-menu.pdf לשורש ה-repository.
3. היכנסו ל-Settings > Pages.
4. תחת Build and deployment בחרו Deploy from a branch.
5. בחרו branch בשם main ואת התיקייה /(root), ואז Save.
6. GitHub יציג את כתובת האתר. את הכתובת הזו הופכים ל-QR סטטי.

חשוב:
- אל תשנו את שם הקובץ menu.pdf בלי לעדכן גם את index.html.
- ה-QR לא פג תוקף כל עוד כתובת האתר נשארת פעילה.
